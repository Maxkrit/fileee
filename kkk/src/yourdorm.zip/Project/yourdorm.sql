-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 28, 2023 at 04:21 PM
-- Server version: 8.0.17
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `yourdorm`
--

-- --------------------------------------------------------

--
-- Table structure for table `dataperson`
--

CREATE TABLE `dataperson` (
  `id_room` int(3) NOT NULL,
  `first_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tel` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contract` int(10) NOT NULL,
  `price` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `dataperson`
--

INSERT INTO `dataperson` (`id_room`, `first_name`, `last_name`, `tel`, `email`, `age`, `gender`, `contract`, `price`) VALUES
(101, 'Tanakit', 'Singsung', '0848023497', '1234@gmail.com', '20', 'female', 2, 5000),
(102, '', '', '', '', '', '', 0, 4500),
(103, '', '', '', '', '', '', 0, 50000),
(104, '', '', '', '', '', '', 0, 4700),
(105, '', '', '', '', '', '', 0, 4500),
(106, '', '', '', '', '', '', 0, 4500),
(107, '', '', '', '', '', '', 0, 4500),
(108, '', '', '', '', '', '', 0, 4500),
(201, '', '', '', '', '', '', 0, 4600),
(202, '', '', '', '', '', '', 0, 4600),
(203, '', '', '', '', '', '', 0, 4600),
(204, '', '', '', '', '', '', 0, 4600),
(205, '', '', '', '', '', '', 0, 4600),
(206, '', '', '', '', '', '', 0, 4600),
(207, 'youngYeans', 'eiei', '0845628080', 'nattanicha@gmail.com', '15', 'girl', 1, 4600),
(208, '', '', '', '', '', '', 0, 4600),
(301, '', '', '', '', '', '', 0, 4700),
(302, '', '', '', '', '', '', 0, 4700),
(303, '', '', '', '', '', '', 0, 4700),
(304, '', '', '', '', '', '', 0, 4700),
(305, '', '', '', '', '', '', 0, 4700),
(306, '', '', '', '', '', '', 0, 4700),
(307, '', '', '', '', '', '', 0, 4700),
(308, '', '', '', '', '', '', 0, 4700),
(401, '', '', '', '', '', '', 0, 4800),
(402, '', '', '', '', '', '', 0, 4800),
(403, '', '', '', '', '', '', 0, 4800),
(404, '', '', '', '', '', '', 0, 4800),
(405, '', '', '', '', '', '', 0, 4800),
(406, '', '', '', '', '', '', 0, 4800),
(407, '', '', '', '', '', '', 0, 4800),
(408, '', '', '', '', '', '', 0, 4800);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dataperson`
--
ALTER TABLE `dataperson`
  ADD PRIMARY KEY (`id_room`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dataperson`
--
ALTER TABLE `dataperson`
  MODIFY `id_room` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=409;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
