package Bills;

public abstract class UsageCost implements Calculator{
    
    protected double costPerUnits;
    protected double unitsUsed;
    protected double totalCost;
    
    public double Total(){
        Calculate();
        return totalCost;
    }
    
}
