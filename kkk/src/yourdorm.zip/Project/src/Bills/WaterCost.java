package Bills;

public class WaterCost extends UsageCost{
    public static double WaterPerUnits = 0;
    
    public WaterCost(double unitsUsed){

        this.unitsUsed = unitsUsed;
    }
    @Override
    public void Calculate() {
       totalCost = WaterPerUnits * unitsUsed;
    }
    
}
