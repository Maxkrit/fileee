package Bills;

public class ElectricCost extends UsageCost{
    public static double ElecPerUnits = 0;
    
    public ElectricCost(double unitsUsed){
        costPerUnits = ElecPerUnits;
        this.unitsUsed = unitsUsed;
    }

    @Override
    public void Calculate() {
       totalCost = ElecPerUnits * unitsUsed;
    }
    
}
