package Bills;

public class CreateCalculator {
    
    public double Call(UsageCost usageCost){
        return usageCost.Total();
    }
}
