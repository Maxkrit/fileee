package Bills;

public class SpecialCost extends UsageCost{
    
    public SpecialCost(double unitsUsed){
        costPerUnits = 1;
        this.unitsUsed = unitsUsed;
    }

    @Override
    public void Calculate() {
       totalCost = costPerUnits * unitsUsed;
    }
    
}
