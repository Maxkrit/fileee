package Bills;

public class AllCost extends UsageCost{
    
    private double water, electric, rent, special;
    private double WaterPerUnits, ElecPerUnits, RoomCost, specialCost;
    
    public AllCost(double WaterPerUnits, double ElecPerUnits, double RoomCost, double specialCost){
        this.WaterPerUnits = WaterPerUnits;
        this.ElecPerUnits = ElecPerUnits;
        this.RoomCost = RoomCost;
        this.specialCost = specialCost;
        Calculate();
    }

    @Override
    public void Calculate() {
        water = (new CreateCalculator().Call(new WaterCost(WaterPerUnits)));
        electric = (new CreateCalculator().Call(new ElectricCost(ElecPerUnits)));
        rent = (new CreateCalculator().Call(new RentCost(RoomCost)));
        special = (new CreateCalculator().Call(new SpecialCost(specialCost)));
        totalCost = water + electric + rent + special;
    }

    
    
    
    
}
