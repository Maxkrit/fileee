package Bills;

public interface Calculator {
    public abstract void Calculate();
}
