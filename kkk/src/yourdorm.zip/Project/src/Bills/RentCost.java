package Bills;

public class RentCost extends UsageCost{
    
    public RentCost(double unitsUsed){
        costPerUnits = 1;
        this.unitsUsed = unitsUsed;
    }

    @Override
    public void Calculate() {
       totalCost = costPerUnits * unitsUsed;
    }
    
}
