package View;

import javax.swing.JOptionPane;
import javax.swing.plaf.basic.BasicInternalFrameUI;

public class Home extends javax.swing.JInternalFrame {
    private YourDormFrame yourDorm;

    public Home(YourDormFrame yourDorm) {
        this.yourDorm = yourDorm;
        initComponents();
        this.setBorder(javax.swing.BorderFactory.createEmptyBorder(0,0,0,0));
        BasicInternalFrameUI ui = (BasicInternalFrameUI) this.getUI();
        ui.setNorthPane(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton2 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        enterButton = new javax.swing.JButton();
        BackToHomeButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        jButton2.setText("Utilities");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 360, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 0, 360, -1));

        jLabel3.setText("Password:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 230, -1, -1));

        jTextField2.setColumns(10);
        jPanel1.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 230, -1, -1));

        enterButton.setText("Enter");
        enterButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                enterButtonActionPerformed(evt);
            }
        });
        jPanel1.add(enterButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 290, -1, -1));

        BackToHomeButton.setText("Back");
        BackToHomeButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                BackToHomeButtonMousePressed(evt);
            }
        });
        BackToHomeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackToHomeButtonActionPerformed(evt);
            }
        });
        jPanel1.add(BackToHomeButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 560, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pic/home.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 810, 618));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

    }//GEN-LAST:event_jButton2ActionPerformed

    private void enterButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_enterButtonActionPerformed
        if("12345".equals(jTextField2.getText())){
            Frame1 fr = new Frame1(yourDorm, "home");
            fr.setSize(810, 610);
            yourDorm.getJDesktop().removeAll();
            yourDorm.getJDesktop().add(fr).setVisible(true);
        }
        else{
            JOptionPane.showMessageDialog(null, "Wrong Password", "Fail", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_enterButtonActionPerformed

    private void BackToHomeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackToHomeButtonActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_BackToHomeButtonActionPerformed

    private void BackToHomeButtonMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BackToHomeButtonMousePressed
        // TODO add your handling code here:
        User user = new User(yourDorm);
        user.setSize(800, 600);
        yourDorm.getJDesktop().removeAll();
        yourDorm.getJDesktop().add(user).setVisible(true);
    }//GEN-LAST:event_BackToHomeButtonMousePressed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BackToHomeButton;
    private javax.swing.JButton enterButton;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField jTextField2;
    // End of variables declaration//GEN-END:variables
}
