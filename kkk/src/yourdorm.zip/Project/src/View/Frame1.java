package View;

import java.awt.Color;
import javax.swing.JDesktopPane;
import javax.swing.JLabel;
import javax.swing.plaf.basic.BasicInternalFrameUI;

public class Frame1 extends javax.swing.JInternalFrame {
    private YourDormFrame yourDorm;
    private String page;

    public Frame1(YourDormFrame yourDorm) {
        this.yourDorm = yourDorm;
        initComponents();
        this.setBorder(javax.swing.BorderFactory.createEmptyBorder(0,0,0,0));
        BasicInternalFrameUI ui = (BasicInternalFrameUI) this.getUI();
        ui.setNorthPane(null);
    }
    
    public Frame1(YourDormFrame yourDorm, String page) {
        this.page = page;
        this.yourDorm = yourDorm;
        initComponents();
        this.setBorder(javax.swing.BorderFactory.createEmptyBorder(0,0,0,0));
        BasicInternalFrameUI ui = (BasicInternalFrameUI) this.getUI();
        ui.setNorthPane(null);
        if(page.equals("home")){
            OwnerHome ownerHome = new OwnerHome(yourDorm);
            jDesktopPane1.removeAll();
            jDesktopPane1.add(ownerHome).setVisible(true);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        logout = new javax.swing.JLabel();
        utilitybutton = new javax.swing.JLabel();
        roomButton = new javax.swing.JLabel();
        tenantButton = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jDesktopPane1 = new javax.swing.JDesktopPane();

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));

        logout.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        logout.setText("Logout");
        logout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                logoutMousePressed(evt);
            }
        });

        utilitybutton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        utilitybutton.setText("Utilities bills");
        utilitybutton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                utilitybuttonMousePressed(evt);
            }
        });

        roomButton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        roomButton.setText("rooms");
        roomButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                roomButtonMousePressed(evt);
            }
        });

        tenantButton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        tenantButton.setText("tenants");
        tenantButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tenantButtonMousePressed(evt);
            }
        });

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("YOURDORM");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(122, 122, 122)
                .addComponent(logout)
                .addGap(63, 63, 63)
                .addComponent(utilitybutton)
                .addGap(63, 63, 63)
                .addComponent(roomButton)
                .addGap(70, 70, 70)
                .addComponent(tenantButton)
                .addContainerGap(79, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(logout)
                    .addComponent(utilitybutton)
                    .addComponent(roomButton)
                    .addComponent(tenantButton))
                .addContainerGap(35, Short.MAX_VALUE))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jDesktopPane1.setPreferredSize(new java.awt.Dimension(800, 382));

        javax.swing.GroupLayout jDesktopPane1Layout = new javax.swing.GroupLayout(jDesktopPane1);
        jDesktopPane1.setLayout(jDesktopPane1Layout);
        jDesktopPane1Layout.setHorizontalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jDesktopPane1Layout.setVerticalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 382, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jDesktopPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 788, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jDesktopPane1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void utilitybuttonMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_utilitybuttonMousePressed
        Utility uti = new Utility(this);
        uti.setSize(800, 509);
        jDesktopPane1.removeAll();
        jDesktopPane1.add(uti).setVisible(true);
        utilitybutton.setForeground(Color.BLUE);
        roomButton.setForeground(Color.BLACK);
        uti.getBill().setBackground(new java.awt.Color(153, 204, 255));
        tenantButton.setForeground(Color.BLACK);
    }//GEN-LAST:event_utilitybuttonMousePressed

    private void logoutMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutMousePressed
        User user = new User(yourDorm);
        user.setSize(800, 600);
        yourDorm.getJDesktop().removeAll();
        yourDorm.getJDesktop().add(user).setVisible(true);
    }//GEN-LAST:event_logoutMousePressed

    private void roomButtonMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_roomButtonMousePressed
        Room room = new Room(this);
        room.setSize(800, 609);
        jDesktopPane1.removeAll();
        jDesktopPane1.add(room).setVisible(true);
        roomButton.setForeground(Color.BLUE);
        utilitybutton.setForeground(Color.BLACK);
        tenantButton.setForeground(Color.BLACK);
    }//GEN-LAST:event_roomButtonMousePressed

    private void tenantButtonMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tenantButtonMousePressed
        Tenant tenant = new Tenant();
        tenant.setSize(800, 609);
        jDesktopPane1.removeAll();
        jDesktopPane1.add(tenant).setVisible(true);
        tenantButton.setForeground(Color.BLUE);
        utilitybutton.setForeground(Color.BLACK);
        roomButton.setForeground(Color.BLACK);
    }//GEN-LAST:event_tenantButtonMousePressed

    public JLabel getUtilitybutton() {
        return utilitybutton;
    }

    public JDesktopPane getjDesktopPane1() {
        return jDesktopPane1;
    }

    public JLabel getRoomButton() {
        return roomButton;
    }

    public JLabel getTenant() {
        return tenantButton;
    }

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JLabel logout;
    private javax.swing.JLabel roomButton;
    private javax.swing.JLabel tenantButton;
    private javax.swing.JLabel utilitybutton;
    // End of variables declaration//GEN-END:variables
}
