package View;

import Bills.ElectricCost;
import Bills.WaterCost;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class PrintBill extends javax.swing.JInternalFrame {
    
    public PrintBill(Bill b) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
        LocalDateTime now = LocalDateTime.now();
        initComponents();
        name.setText(b.getOwnerName().getText());
        room.setText(b.getRoomID().getText());
        rUnit.setText("1");
        eUnit.setText(b.geteUnit().getText());
        wUnit.setText(b.getwUnit().getText());
        eCost.setText(ElectricCost.ElecPerUnits + "");
        wCost.setText(WaterCost.WaterPerUnits + "");
        rCost.setText(b.getrCost().getText());
        sCost.setText(b.getsCost().getText());
        sTotal.setText(b.getsCost().getText());
        rTotal.setText(b.getrCost().getText());
        eTotal.setText(b.geteCost().getText());
        wTotal.setText(b.getwCost().getText());
        total.setText(b.getTotal().getText());
        date.setText(dtf.format(now));
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        Enter = new javax.swing.JButton();
        room = new javax.swing.JLabel();
        rUnit = new javax.swing.JLabel();
        eUnit = new javax.swing.JLabel();
        wUnit = new javax.swing.JLabel();
        rCost = new javax.swing.JLabel();
        eCost = new javax.swing.JLabel();
        wCost = new javax.swing.JLabel();
        sCost = new javax.swing.JLabel();
        rTotal = new javax.swing.JLabel();
        eTotal = new javax.swing.JLabel();
        wTotal = new javax.swing.JLabel();
        sTotal = new javax.swing.JLabel();
        total = new javax.swing.JLabel();
        date = new javax.swing.JLabel();
        name = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        jLabel4.setText("jLabel2");

        jLabel5.setText("jLabel2");

        jLabel9.setText("jLabel2");

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Enter.setText("Done");
        Enter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EnterActionPerformed(evt);
            }
        });
        jPanel1.add(Enter, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 440, -1, -1));

        room.setText("jLabel2");
        jPanel1.add(room, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 70, -1, -1));

        rUnit.setText("jLabel2");
        jPanel1.add(rUnit, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 180, -1, -1));

        eUnit.setText("jLabel2");
        jPanel1.add(eUnit, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 220, -1, -1));

        wUnit.setText("jLabel2");
        jPanel1.add(wUnit, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 260, -1, -1));

        rCost.setText("jLabel2");
        jPanel1.add(rCost, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 180, -1, -1));

        eCost.setText("jLabel2");
        jPanel1.add(eCost, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 220, -1, -1));

        wCost.setText("jLabel2");
        jPanel1.add(wCost, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 260, -1, -1));

        sCost.setText("jLabel2");
        jPanel1.add(sCost, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 310, -1, -1));

        rTotal.setText("jLabel2");
        jPanel1.add(rTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 180, -1, -1));

        eTotal.setText("jLabel2");
        jPanel1.add(eTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 220, -1, -1));

        wTotal.setText("jLabel2");
        jPanel1.add(wTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 260, -1, -1));

        sTotal.setText("jLabel2");
        jPanel1.add(sTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 310, -1, -1));

        total.setText("jLabel2");
        jPanel1.add(total, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 340, -1, -1));

        date.setText("jLabel2");
        jPanel1.add(date, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 390, -1, -1));

        name.setText("jLabel2");
        jPanel1.add(name, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 70, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pic/bill.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, 610, 446));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 497, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void EnterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EnterActionPerformed
        dispose();
    }//GEN-LAST:event_EnterActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Enter;
    private javax.swing.JLabel date;
    private javax.swing.JLabel eCost;
    private javax.swing.JLabel eTotal;
    private javax.swing.JLabel eUnit;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel name;
    private javax.swing.JLabel rCost;
    private javax.swing.JLabel rTotal;
    private javax.swing.JLabel rUnit;
    private javax.swing.JLabel room;
    private javax.swing.JLabel sCost;
    private javax.swing.JLabel sTotal;
    private javax.swing.JLabel total;
    private javax.swing.JLabel wCost;
    private javax.swing.JLabel wTotal;
    private javax.swing.JLabel wUnit;
    // End of variables declaration//GEN-END:variables
}
