package View;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.plaf.basic.BasicInternalFrameUI;

public class User extends javax.swing.JInternalFrame {
    private YourDormFrame yourDorm;
    private String password;

    public User(YourDormFrame yourDorm) {
        initComponents();
        this.setBorder(javax.swing.BorderFactory.createEmptyBorder(0,0,0,0));
        BasicInternalFrameUI ui = (BasicInternalFrameUI) this.getUI();
        ui.setNorthPane(null);
        
        password = "12345";
        this.yourDorm = yourDorm;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jCheckBoxMenuItem1 = new javax.swing.JCheckBoxMenuItem();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        ownerButton = new javax.swing.JPanel();
        owner = new javax.swing.JLabel();
        tenantButton = new javax.swing.JPanel();
        tenant = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        BG = new javax.swing.JLabel();

        jCheckBoxMenuItem1.setSelected(true);
        jCheckBoxMenuItem1.setText("jCheckBoxMenuItem1");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ownerButton.setBackground(new java.awt.Color(255, 255, 255));
        ownerButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ownerButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ownerButtonMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ownerButtonMousePressed(evt);
            }
        });

        owner.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        owner.setForeground(new java.awt.Color(0, 102, 153));
        owner.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        owner.setText("OWNER");

        javax.swing.GroupLayout ownerButtonLayout = new javax.swing.GroupLayout(ownerButton);
        ownerButton.setLayout(ownerButtonLayout);
        ownerButtonLayout.setHorizontalGroup(
            ownerButtonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ownerButtonLayout.createSequentialGroup()
                .addGap(97, 97, 97)
                .addComponent(owner)
                .addContainerGap(105, Short.MAX_VALUE))
        );
        ownerButtonLayout.setVerticalGroup(
            ownerButtonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(owner, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );

        jPanel2.add(ownerButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 280, 270, 50));

        tenantButton.setBackground(new java.awt.Color(255, 255, 255));
        tenantButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tenantButtonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                tenantButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                tenantButtonMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tenantButtonMousePressed(evt);
            }
        });

        tenant.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        tenant.setForeground(new java.awt.Color(0, 102, 153));
        tenant.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tenant.setText("TENANT");

        javax.swing.GroupLayout tenantButtonLayout = new javax.swing.GroupLayout(tenantButton);
        tenantButton.setLayout(tenantButtonLayout);
        tenantButtonLayout.setHorizontalGroup(
            tenantButtonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tenantButtonLayout.createSequentialGroup()
                .addGap(97, 97, 97)
                .addComponent(tenant)
                .addContainerGap(105, Short.MAX_VALUE))
        );
        tenantButtonLayout.setVerticalGroup(
            tenantButtonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tenantButtonLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tenant, javax.swing.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel2.add(tenantButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 360, -1, -1));

        jLabel2.setForeground(new java.awt.Color(0, 51, 51));
        jLabel2.setText("choose your position");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 230, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pic/Logo.png"))); // NOI18N
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 100, -1, -1));

        BG.setBackground(new java.awt.Color(0, 0, 0));
        BG.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pic/BG1.png"))); // NOI18N
        jPanel2.add(BG, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, 810, 630));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ownerButtonMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ownerButtonMousePressed
        Home home = new Home(yourDorm);
        home.setSize(820, 620);
        yourDorm.getJDesktop().removeAll();
        yourDorm.getJDesktop().add(home).setVisible(true); 
          
    }//GEN-LAST:event_ownerButtonMousePressed

    private void ownerButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ownerButtonMouseEntered
        ownerButton.setBackground(new java.awt.Color(0, 102, 153));
        owner.setForeground(Color.WHITE);
    }//GEN-LAST:event_ownerButtonMouseEntered

    private void ownerButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ownerButtonMouseExited
        ownerButton.setBackground(Color.WHITE);
        owner.setForeground(new java.awt.Color(0, 102, 153));
    }//GEN-LAST:event_ownerButtonMouseExited

    private void tenantButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tenantButtonMouseEntered
        tenantButton.setBackground(new java.awt.Color(0, 102, 153));
        tenant.setForeground(Color.WHITE);
    }//GEN-LAST:event_tenantButtonMouseEntered

    private void tenantButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tenantButtonMouseClicked
        
    }//GEN-LAST:event_tenantButtonMouseClicked

    private void tenantButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tenantButtonMouseExited
        tenantButton.setBackground(Color.WHITE);
        tenant.setForeground(new java.awt.Color(0, 102, 153));
    }//GEN-LAST:event_tenantButtonMouseExited

    private void tenantButtonMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tenantButtonMousePressed
        Frame2 f = new Frame2(yourDorm, "home");
        f.setSize(800, 600);
        yourDorm.getJDesktop().removeAll();
        yourDorm.getJDesktop().add(f).setVisible(true); 
    }//GEN-LAST:event_tenantButtonMousePressed

    public JLabel getBG() {
        return BG;
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel BG;
    private javax.swing.JCheckBoxMenuItem jCheckBoxMenuItem1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel owner;
    private javax.swing.JPanel ownerButton;
    private javax.swing.JLabel tenant;
    private javax.swing.JPanel tenantButton;
    // End of variables declaration//GEN-END:variables
}
