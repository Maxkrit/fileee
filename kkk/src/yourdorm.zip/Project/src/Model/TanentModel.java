package Model;

import static Model.Connector.connection;
import java.sql.*;

public class TanentModel implements DataRoom{
    private String firstName, lastName, tel, email, age, gender;
    private int contract;
    
    public TanentModel(){
        this.firstName = "";
        this.lastName = "";
        this.tel = "";
        this.email = "";
        this.age = "";
        this.gender = "";
        this.contract = 0;
    }
    
    public boolean checkDataRoom(int id_room){
        boolean check = false;
        try{
            String sql = "SELECT * FROM dataperson WHERE id_room = ?";
            PreparedStatement pr = connection().prepareStatement(sql);
            pr.setInt(1, id_room);
            ResultSet rs = pr.executeQuery();
            if(rs.next()){
                check = true;
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return check;
    }
    
    @Override
    public void setDataRoom(int id_room){
        try{
            String sql = "SELECT * FROM dataperson WHERE id_room = ?";
            PreparedStatement pr = connection().prepareStatement(sql);
            pr.setInt(1, id_room);
            ResultSet rs = pr.executeQuery();
            if(rs.next()){
                firstName = rs.getString("first_name");
                lastName = rs.getString("last_name");
                tel = rs.getString("tel");
                email = rs.getString("email");
                age = rs.getString("age");
                gender = rs.getString("gender");
                contract = rs.getInt("contract");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void updateDataRoom(int id_room, String firstName, String lastName, String tel, String email, String age, String gender, int contract){
        try{
            String sql = "UPDATE dataperson SET first_name = ?, last_name = ?, "
                    + "tel = ?, email = ?, age= ?, gender = ?, contract = ? WHERE id_room = ?";
            PreparedStatement pr = connection().prepareStatement(sql);
            pr.setString(1, firstName);
            pr.setString(2, lastName);
            pr.setString(3, tel);
            pr.setString(4, email);
            pr.setString(5, age);
            pr.setString(6, gender);
            pr.setInt(7, contract);
            pr.setInt(8, id_room);
            pr.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void deleteDataRoom(int id_room){
        try{
            String sql = "UPDATE dataperson SET first_name = ?, last_name = ?, "
                    + "tel = ?, email = ?, age= ?, gender = ?, contract = ? WHERE id_room = ?";
            PreparedStatement pr = connection().prepareStatement(sql);
            pr.setString(1, "");
            pr.setString(2, "");
            pr.setString(3, "");
            pr.setString(4, "");
            pr.setString(5, "");
            pr.setString(6, "");
            pr.setInt(7, 0);
            pr.setInt(8, id_room);
            pr.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getTel() {
        return tel;
    }

    public String getEmail() {
        return email;
    }

    public String getAge() {
        return age;
    }

    public String getGender() {
        return gender;
    }

    public int getContract() {
        return contract;
    }
    
}
