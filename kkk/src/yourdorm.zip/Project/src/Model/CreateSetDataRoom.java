package Model;

public class CreateSetDataRoom {
    
    public void callSetDataRoom(DataRoom dataRoom, int id_room){
        dataRoom.setDataRoom(id_room);
    }
}
