package Model;

import View.RoomEmpty;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

public class ShowRoomEmptyModel {
    
    public ShowRoomEmptyModel(RoomEmpty roomEmpty, RoomModel roomModel){
        showRoomEmpty(roomEmpty, roomModel);
    }
    
    public void showRoomEmpty(RoomEmpty roomEmpty, RoomModel roomModel){
        ArrayList<DataInfo> datalist = roomModel.getDataInfo();
        DefaultTableModel model = (DefaultTableModel)roomEmpty.getjTable1().getModel();
        model.setRowCount(0);
        Object[] rowData = new Object[3];
        for(int i = 0; i < datalist.size(); i++){
            if("".equals(datalist.get(i).getFirstName())){
                rowData[0] = datalist.get(i).getId_room();
                rowData[1] = "Empty";
                rowData[2] = datalist.get(i).getPrice();
                model.addRow(rowData);
            }
        }
    }
}
