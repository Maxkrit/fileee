package Model;

import static Model.Connector.connection;
import java.sql.*;

public class SettingPriceRoomModel {
    
    public SettingPriceRoomModel(int id_room, int priceRoom){
        updatePriceRoom(id_room, priceRoom);
    }
    
    public void updatePriceRoom(int id_room, int priceRoom){
        try{
            String sql = "UPDATE dataperson SET price = ? WHERE id_room = ?";
            PreparedStatement pr = connection().prepareStatement(sql);
            pr.setInt(1, priceRoom);
            pr.setInt(2, id_room);
            pr.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
