package Model;

public class DataInfo {
    private int id_room, contract, price;
    private String firstName, lastName, tel, email, age, gender;
    
    public DataInfo(int id_room, String firstName, String lastName, String tel, String email, String age, String gender, int contract, int price){
        this.id_room = id_room;
        this.firstName = firstName;
        this.lastName = lastName;
        this.tel = tel;
        this.email = email;
        this.age = age;
        this.gender = gender;
        this.contract = contract;
        this.price = price;
    }

    public int getId_room() {
        return id_room;
    }

    public int getContract() {
        return contract;
    }

    public int getPrice() {
        return price;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getTel() {
        return tel;
    }

    public String getEmail() {
        return email;
    }

    public String getAge() {
        return age;
    }

    public String getGender() {
        return gender;
    }

    
    
}
