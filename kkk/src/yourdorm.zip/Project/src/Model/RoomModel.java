package Model;

import static Model.Connector.connection;
import View.Room;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

public class RoomModel {
    
    public RoomModel(Room room){
        showDataInTable(room);
    }

    public RoomModel() {
        
    }
    
    public ArrayList<DataInfo> getDataInfo(){
        ArrayList<DataInfo> datalist = new ArrayList<DataInfo>();
        DataInfo dataInfo;
        try{
            String sql = "SELECT * FROM `dataperson`";
            PreparedStatement ps = connection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                dataInfo = new DataInfo(rs.getInt("id_room"), rs.getString("first_name"), 
                        rs.getString("last_name"), rs.getString("tel"), rs.getString("email"), 
                        rs.getString("age"), rs.getString("gender"), rs.getInt("contract"), rs.getInt("price"));
                datalist.add(dataInfo);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return datalist;
    }
    
    public void showDataInTable(Room room){
        ArrayList<DataInfo> datalist = getDataInfo();
        DefaultTableModel model = (DefaultTableModel)room.getjTable1().getModel();
        model.setRowCount(0);
        Object[] rowData = new Object[3];
        for(int i = 0; i < datalist.size(); i++){
            if("".equals(datalist.get(i).getFirstName())){
                rowData[0] = datalist.get(i).getId_room();
                rowData[1] = "Empty";
                rowData[2] = datalist.get(i).getPrice();
            }
            else{
                rowData[0] = datalist.get(i).getId_room();
                rowData[1] = datalist.get(i).getFirstName()+ " " + datalist.get(i).getLastName();
                rowData[2] = datalist.get(i).getPrice();
            }
            model.addRow(rowData);
        }
    }
}
