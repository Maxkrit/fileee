package Model;

public interface DataRoom {
    void setDataRoom(int id_room);
}
