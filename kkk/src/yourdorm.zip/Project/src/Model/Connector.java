package Model;

import java.sql.*;

public class Connector {
    
    public static Connection connection(){
        Connection connect = null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            connect = DriverManager.getConnection("jdbc:mysql://localhost/yourdorm", "root", "0848023497");
        }catch(Exception e){
            e.printStackTrace();
        }
        return connect;
    }
}
