package Model;

import static Model.Connector.connection;
;
import java.sql.*;

public class BillModel implements DataRoom{
    private String firstName, lastName, tel, age, gender;
    private int contract, roomprice, id_room;
    
    public BillModel(int id_room){
        this.id_room = id_room;
        setDataRoom(id_room);
    }
    
    @Override
    public void setDataRoom(int id_room){
        try{
            String sql = "SELECT * FROM dataperson WHERE id_room = ?";
            PreparedStatement pr = connection().prepareStatement(sql);
            pr.setInt(1, id_room);
            ResultSet rs = pr.executeQuery();
            if(rs.next()){
                firstName = rs.getString("first_name");
                lastName = rs.getString("last_name");
                tel = rs.getString("tel");
                age = rs.getString("age");
                gender = rs.getString("gender");
                contract = rs.getInt("contract");
                roomprice = rs.getInt("price");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public int getRoomprice() {
        return roomprice;
    }

    public String getTel() {
        return tel;
    }

    public String getAge() {
        return age;
    }

    public String getGender() {
        return gender;
    }

    public int getContract() {
        return contract;
    }

    public int getId_room() {
        return id_room;
    }
    
}
